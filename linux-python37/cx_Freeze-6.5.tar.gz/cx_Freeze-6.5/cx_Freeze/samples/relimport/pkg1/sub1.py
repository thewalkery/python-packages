print("importing pkg1.sub1")

from . import sub2
