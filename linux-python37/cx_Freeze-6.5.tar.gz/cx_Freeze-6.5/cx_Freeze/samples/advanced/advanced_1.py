#!/usr/bin/env python


print("Hello from cx_Freeze Advanced #1\n")

module = __import__("testfreeze_1")
