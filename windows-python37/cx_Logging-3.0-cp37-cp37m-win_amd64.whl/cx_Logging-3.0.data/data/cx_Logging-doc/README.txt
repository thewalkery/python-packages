Open Source Python Utility - cx_Logging

cx_Logging is a Python extension module which operates in a fashion similar to
the logging module that ships with Python 2.3 and higher. It also has a C
interface which allows applications to perform logging independently of Python.

This project is being released to the public since other projects that are
available publicly depend on this module.

Please see the included documentation for additional information. Note that
the documentation is a work in progress. It is currently only suitable as
reference material but I intend to supplement this documentation over time.

