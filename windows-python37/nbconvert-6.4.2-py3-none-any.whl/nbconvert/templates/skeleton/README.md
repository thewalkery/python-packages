## Template skeleton

This directory contains the template skeleton files.

Do not modify the contents of the `../latex/skeleton` folder.  Instead, 
if you need to, make modifications to the files in this folder and then run
`make` to generate the corresponding latex skeleton files in the 
`../latex/skeleton` folder.

If you would like to share your resulting templates with others, we encourage
[sharing those links on our wiki
page](https://github.com/ipython/ipython/wiki/Cookbook:%20nbconvert%20templates).
